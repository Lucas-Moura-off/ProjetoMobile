package dev.whallyson.entitys.user;

// Enum do tipo de usuário
public enum UserType {
    COMMON,
    MERCHANT
}
